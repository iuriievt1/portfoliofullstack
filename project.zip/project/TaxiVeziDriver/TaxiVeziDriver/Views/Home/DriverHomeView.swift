//
//  DriverHomeView.swift
//  TaxiVeziDriver
//
//  Created by Iurii Evteev on 12/15/25.
//

import SwiftUI
import MapKit

struct DriverHomeView: View {
    @StateObject private var locationManager = LocationManager()

    @State private var isOnline: Bool = false
    @State private var todaysEarnings: Int = 0
    @State private var todaysTrips: Int = 0

    @State private var showActiveRide: Bool = false

    var body: some View {
        ZStack {
            Map(coordinateRegion: $locationManager.region, showsUserLocation: true)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                HStack {
                    Text("Taxi Vezi – Řidič")
                        .font(.headline)
                        .fontWeight(.bold)
                        .padding(8)
                        .background(Color.white.opacity(0.9))
                        .cornerRadius(12)

                    Spacer()

                    Circle()
                        .fill(isOnline ? Color.green : Color.gray)
                        .frame(width: 10, height: 10)
                }
                .padding(.top, 16)
                .padding(.horizontal, 16)

                Spacer()

                VStack(spacing: 16) {
                    Capsule()
                        .fill(Color.gray.opacity(0.3))
                        .frame(width: 40, height: 4)
                        .padding(.top, 6)

                    VStack(spacing: 12) {
                        HStack {
                            Text(isOnline ? "Jste online" : "Jste offline")
                                .font(.headline)
                                .fontWeight(.semibold)

                            Spacer()

                            Circle()
                                .fill(isOnline ? Color.green : Color.gray)
                                .frame(width: 10, height: 10)
                        }

                        Toggle(isOn: $isOnline) {
                            Text(isOnline ? "Přijímám jízdy" : "Nepřijímám jízdy")
                                .font(.subheadline)
                        }
                        .tint(.red)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Dnešní statistika").font(.headline)

                        HStack(spacing: 16) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("\(todaysEarnings) Kč").font(.title3).fontWeight(.semibold)
                                Text("Výdělek dnes").font(.caption).foregroundColor(.gray)
                            }

                            Spacer()

                            VStack(alignment: .leading, spacing: 4) {
                                Text("\(todaysTrips)").font(.title3).fontWeight(.semibold)
                                Text("Počet jízd").font(.caption).foregroundColor(.gray)
                            }

                            Spacer()
                        }
                    }

                    VStack(spacing: 8) {
                        if isOnline {
                            Image(systemName: "dot.radiowaves.left.and.right")
                                .font(.system(size: 32))
                                .foregroundColor(.red)

                            Text("Čekáme na novou jízdu…")
                                .font(.subheadline)
                                .fontWeight(.medium)

                            Text("Jakmile se objeví objednávka ve vaší oblasti, zobrazíme ji zde k přijetí.")
                                .font(.caption)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 24)

                            Button { showActiveRide = true } label: {
                                Text("Simulovat aktivní jízdu")
                                    .font(.caption)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(Color.red.opacity(0.1))
                                    .foregroundColor(.red)
                                    .cornerRadius(12)
                            }
                            .padding(.top, 4)
                        } else {
                            Image(systemName: "moon.zzz.fill")
                                .font(.system(size: 32))
                                .foregroundColor(.gray)

                            Text("Jste offline")
                                .font(.subheadline)
                                .fontWeight(.medium)

                            Text("Přepněte se do režimu online, pokud chcete začít přijímat nové jízdy.")
                                .font(.caption)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 24)
                        }
                    }
                    .padding(.bottom, 8)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 24)
                .background(
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .fill(.ultraThinMaterial)
                        .shadow(color: Color.black.opacity(0.2), radius: 18, x: 0, y: -4)
                )
                .padding(.horizontal, 16)
                .padding(.bottom, 8)
            }
        }
        .sheet(isPresented: $showActiveRide) {
            DriverActiveRideView(
                pickup: "Ramonova 10, Praha 8",
                destination: "Václavské náměstí",
                estimatedPrice: "190–220 Kč",
                initialEtaMinutes: 5
            )
        }
    }
}

#Preview { DriverHomeView() }
