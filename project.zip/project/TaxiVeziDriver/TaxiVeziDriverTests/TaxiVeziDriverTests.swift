//
//  TaxiVeziDriverTests.swift
//  TaxiVeziDriverTests
//
//  Created by Iurii Evteev on 12/15/25.
//

import Testing
@testable import TaxiVeziDriver

struct TaxiVeziDriverTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
