//
//  DriverRideOfferDetailView.swift
//  TaxiVeziDriver
//
//  Created by Iurii Evteev on 12/15/25.
//

import SwiftUI

struct DriverRideOfferDetailView: View {
    let offer: RideOffer
    let onAccept: () -> Void
    let onReject: () -> Void

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                VStack(spacing: 8) {
                    Text("Nová nabídka jízdy").font(.title3).fontWeight(.semibold)
                    Text("\(offer.pickup) → \(offer.destination)")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                }
                .padding(.top, 24)
                .padding(.horizontal, 24)

                VStack(alignment: .leading, spacing: 12) {
                    HStack { Text("Vzdálenost k pasažérovi"); Spacer(); Text("\(String(format: "%.1f", offer.distanceToPickupKm)) km").foregroundColor(.gray) }
                    HStack { Text("Délka jízdy"); Spacer(); Text("\(String(format: "%.1f", offer.estimatedTripKm)) km").foregroundColor(.gray) }
                    HStack { Text("Odhadovaná cena"); Spacer(); Text(offer.estimatedPrice).fontWeight(.semibold) }
                    HStack { Text("Čas příjezdu"); Spacer(); Text("\(offer.etaMinutes) min").foregroundColor(.gray) }
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color(.systemBackground))
                        .shadow(color: Color.black.opacity(0.06), radius: 8, x: 0, y: 2)
                )
                .padding(.horizontal, 16)

                Spacer()

                VStack(spacing: 12) {
                    Button {
                        onAccept()
                        dismiss()
                    } label: {
                        Text("Přijmout jízdu")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(16)
                    }

                    Button {
                        onReject()
                        dismiss()
                    } label: {
                        Text("Odmítnout")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red.opacity(0.1))
                            .foregroundColor(.red)
                            .cornerRadius(16)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 24)
            }
            .navigationTitle("Nabídka jízdy")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

