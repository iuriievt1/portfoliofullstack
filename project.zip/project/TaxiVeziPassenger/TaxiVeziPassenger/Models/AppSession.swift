//
//  AppSession.swift
//  TaxiVeziPassenger
//
//  Created by Iurii Evteev on 12/15/25.
//

import Foundation
import Combine

final class AppSession: ObservableObject {
    @Published var isLoggedIn: Bool = false
    @Published var authToken: String? = nil
    @Published var passengerPhone: String = ""

    func logout() {
        isLoggedIn = false
        authToken = nil
        passengerPhone = ""
    }
}
