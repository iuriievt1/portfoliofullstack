//
//  DriverAuthAPI.swift
//  TaxiVeziDriver
//
//  Created by Iurii Evteev on 12/15/25.
//

import Foundation

private struct DriverStartLoginResponse: Codable {
    let success: Bool
    let message: String?
}

private struct DriverVerifyResponse: Codable {
    let success: Bool
    let message: String?
    let token: String?
    let driver: DriverInfoPayload?
}

private struct DriverInfoPayload: Codable {
    let id: String?
    let name: String?
    let phone: String?
}

enum DriverAuthAPIError: Error, LocalizedError {
    case invalidURL
    case badResponse
    case server(String)
    case noToken

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid URL"
        case .badResponse: return "Bad response from server"
        case .server(let msg): return msg
        case .noToken: return "Missing token in response"
        }
    }
}

struct DriverAuthAPI {

    private let baseURL = URL(string: "http://localhost:4000")!

    private func makeRequest(
        path: String,
        method: String = "POST",
        body: Data? = nil
    ) async throws -> Data {
        guard let url = URL(string: path, relativeTo: baseURL) else {
            throw DriverAuthAPIError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            // покажем тело если надо — но пока просто error
            throw DriverAuthAPIError.badResponse
        }

        return data
    }

    func startLogin(phone: String) async throws {
        let payload: [String: Any] = ["phone": phone]
        let body = try JSONSerialization.data(withJSONObject: payload, options: [])

        let data = try await makeRequest(path: "/auth/driver/request-code", method: "POST", body: body)
        let decoded = try JSONDecoder().decode(DriverStartLoginResponse.self, from: data)

        if decoded.success == false {
            throw DriverAuthAPIError.server(decoded.message ?? "Unknown error")
        }
    }

    func verifyCode(phone: String, code: String) async throws -> (token: String, name: String?) {
        let payload: [String: Any] = ["phone": phone, "code": code]
        let body = try JSONSerialization.data(withJSONObject: payload, options: [])

        let data = try await makeRequest(path: "/auth/driver/verify", method: "POST", body: body)
        let decoded = try JSONDecoder().decode(DriverVerifyResponse.self, from: data)

        if decoded.success == false {
            throw DriverAuthAPIError.server(decoded.message ?? "Unknown error")
        }

        guard let token = decoded.token else { throw DriverAuthAPIError.noToken }
        return (token, decoded.driver?.name)
    }
}
