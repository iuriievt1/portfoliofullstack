//
//  DriverOrdersView.swift
//  TaxiVeziDriver
//
//  Created by Iurii Evteev on 12/15/25.
//

import SwiftUI

struct DriverOrdersView: View {
    @State private var offers: [RideOffer] = [
        RideOffer(pickup: "Ramonova 10, Praha 8", destination: "Václavské náměstí", distanceToPickupKm: 1.2, estimatedTripKm: 6.5, estimatedPrice: "190–220 Kč", etaMinutes: 4),
        RideOffer(pickup: "Letiště Václava Havla", destination: "Karlín, Praha 8", distanceToPickupKm: 3.8, estimatedTripKm: 17.0, estimatedPrice: "420–480 Kč", etaMinutes: 9)
    ]

    @State private var selectedOffer: RideOffer?

    var body: some View {
        NavigationStack {
            Group {
                if offers.isEmpty {
                    VStack(spacing: 8) {
                        Text("Žádné nabídky jízd").font(.headline)
                        Text("Jakmile budete online a objeví se jízdy ve vašem okolí, zobrazí se zde.")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 32)
                    }
                } else {
                    List(offers) { offer in
                        Button { selectedOffer = offer } label: {
                            RideOfferRowView(offer: offer)
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Nabídky")
        }
        .sheet(item: $selectedOffer) { offer in
            DriverRideOfferDetailView(
                offer: offer,
                onAccept: {
                    print("Řidič přijal jízdu: \(offer.pickup) → \(offer.destination)")
                    selectedOffer = nil
                },
                onReject: {
                    print("Řidič odmítl jízdu: \(offer.pickup) → \(offer.destination)")
                    selectedOffer = nil
                }
            )
        }
    }
}

#Preview { DriverOrdersView() }

