//
//  RidesAPI.swift
//  TaxiVeziPassenger
//
//  Created by Iurii Evteev on 12/15/25.
//

import Foundation

private struct RideResponse: Codable {
    let success: Bool
    let message: String?
    let ride: Ride?
}

private struct RidesListResponse: Codable {
    let success: Bool
    let message: String?
    let rides: [Ride]?
}

enum RidesAPIError: Error, LocalizedError {
    case invalidURL
    case badResponse
    case server(String)
    case noRide

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid URL"
        case .badResponse: return "Bad response from server"
        case .server(let msg): return msg
        case .noRide: return "No ride in response"
        }
    }
}

struct RidesAPI {
    private let baseURL = URL(string: "http://localhost:4000")!

    private func makeRequest(
        path: String,
        method: String = "GET",
        token: String,
        body: Data? = nil
    ) async throws -> Data {
        guard let url = URL(string: path, relativeTo: baseURL) else {
            throw RidesAPIError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.httpBody = body

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            throw RidesAPIError.badResponse
        }
        return data
    }

    func requestRide(
        token: String,
        pickupAddress: String,
        pickupLat: Double,
        pickupLng: Double,
        destinationAddress: String,
        destinationLat: Double,
        destinationLng: Double,
        carType: String
    ) async throws -> Ride {

        let payload: [String: Any] = [
            "pickupAddress": pickupAddress,
            "pickupLat": pickupLat,
            "pickupLng": pickupLng,
            "destinationAddress": destinationAddress,
            "destinationLat": destinationLat,
            "destinationLng": destinationLng,
            "carType": carType
        ]

        let body = try JSONSerialization.data(withJSONObject: payload, options: [])

        let data = try await makeRequest(path: "/rides/request", method: "POST", token: token, body: body)
        let decoded = try JSONDecoder().decode(RideResponse.self, from: data)

        if let message = decoded.message, !decoded.success { throw RidesAPIError.server(message) }
        guard let ride = decoded.ride else { throw RidesAPIError.noRide }
        return ride
    }

    func getActiveRide(token: String) async throws -> Ride? {
        let data = try await makeRequest(path: "/rides/passenger/active", method: "GET", token: token)
        let decoded = try JSONDecoder().decode(RideResponse.self, from: data)

        if let message = decoded.message, !decoded.success { throw RidesAPIError.server(message) }
        return decoded.ride
    }

    func cancelRide(token: String, rideId: String) async throws -> Ride {
        let data = try await makeRequest(path: "/rides/\(rideId)/cancel", method: "POST", token: token)
        let decoded = try JSONDecoder().decode(RideResponse.self, from: data)

        if let message = decoded.message, !decoded.success { throw RidesAPIError.server(message) }
        guard let ride = decoded.ride else { throw RidesAPIError.noRide }
        return ride
    }

    func getPassengerRides(token: String) async throws -> [Ride] {
        let data = try await makeRequest(path: "/rides/passenger", method: "GET", token: token)
        let decoded = try JSONDecoder().decode(RidesListResponse.self, from: data)

        if let message = decoded.message, !decoded.success { throw RidesAPIError.server(message) }
        return decoded.rides ?? []
    }

    func advanceRideStatus(token: String, rideId: String) async throws -> Ride {
        let data = try await makeRequest(path: "/rides/\(rideId)/next-status", method: "POST", token: token)
        let decoded = try JSONDecoder().decode(RideResponse.self, from: data)

        if let message = decoded.message, !decoded.success { throw RidesAPIError.server(message) }
        guard let ride = decoded.ride else { throw RidesAPIError.noRide }
        return ride
    }
}
