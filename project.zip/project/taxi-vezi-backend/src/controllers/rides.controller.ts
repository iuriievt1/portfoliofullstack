import { Request, Response } from "express";
import {
  createRide,
  findRideById,
  findActiveRideForPassenger,
  cancelRideById,
  findRidesForPassenger,
  moveRideToNextStatus,
} from "../models/ride.model";

// POST /rides/request
export async function requestRide(req: Request, res: Response) {
  const user = req.user;
  if (!user || user.role !== "passenger") {
    return res.status(403).json({ success: false, message: "Only passenger can request ride" });
  }

  const {
    pickupAddress,
    pickupLat,
    pickupLng,
    destinationAddress,
    destinationLat,
    destinationLng,
    carType,
  } = req.body || {};

  if (
    !pickupAddress ||
    pickupLat == null ||
    pickupLng == null ||
    !destinationAddress ||
    destinationLat == null ||
    destinationLng == null
  ) {
    return res.status(400).json({
      success: false,
      message: "Missing pickup/destination coordinates or address",
    });
  }

  const ride = createRide({
    passengerId: user.userId,
    pickupAddress,
    pickupLat: Number(pickupLat),
    pickupLng: Number(pickupLng),
    destinationAddress,
    destinationLat: Number(destinationLat),
    destinationLng: Number(destinationLng),
    carType,
  });

  return res.status(201).json({ success: true, ride });
}

// GET /rides/:id
export async function getRideById(req: Request, res: Response) {
  const user = req.user;
  if (!user) return res.status(401).json({ success: false, message: "Unauthorized" });

  const { id } = req.params;
  const ride = findRideById(id);
  if (!ride) return res.status(404).json({ success: false, message: "Ride not found" });

  if (user.role === "passenger" && ride.passengerId !== user.userId) {
    return res.status(403).json({ success: false, message: "Forbidden" });
  }

  return res.json({ success: true, ride });
}

// GET /rides/passenger/active
export async function getActiveRideForPassengerHandler(req: Request, res: Response) {
  const user = req.user;
  if (!user || user.role !== "passenger") {
    return res.status(403).json({ success: false, message: "Only passenger can view active ride" });
  }

  const ride = findActiveRideForPassenger(user.userId);
  return res.json({ success: true, ride: ride ?? null });
}

// POST /rides/:id/cancel
export async function cancelRide(req: Request, res: Response) {
  const user = req.user;
  if (!user || user.role !== "passenger") {
    return res.status(403).json({ success: false, message: "Only passenger can cancel ride" });
  }

  const { id } = req.params;
  const ride = cancelRideById(id, user.userId);

  if (!ride) {
    return res.status(404).json({ success: false, message: "Ride not found or access denied" });
  }

  return res.json({ success: true, ride });
}

// GET /rides/passenger
export async function getPassengerRides(req: Request, res: Response) {
  const user = req.user;
  if (!user || user.role !== "passenger") {
    return res.status(403).json({ success: false, message: "Only passenger can view rides" });
  }

  const rides = findRidesForPassenger(user.userId);
  return res.json({ success: true, rides });
}

// POST /rides/:id/next-status  (DEV TEST)
export async function moveRideToNextStatusHandler(req: Request, res: Response) {
  const user = req.user;
  if (!user || user.role !== "passenger") {
    return res.status(403).json({ success: false, message: "Only passenger can change ride status" });
  }

  const { id } = req.params;

  const ride = findRideById(id);
  if (!ride) return res.status(404).json({ success: false, message: "Ride not found" });

  if (ride.passengerId !== user.userId) {
    return res.status(403).json({ success: false, message: "Forbidden" });
  }

  const updated = moveRideToNextStatus(id);
  if (!updated) return res.status(400).json({ success: false, message: "Cannot move to next status" });

  return res.json({ success: true, ride: updated });
}
