//
//  Colors.swift
//  TaxiVeziPassenger
//
//  Created by Iurii Evteev on 12/15/25.
//

import SwiftUI

extension Color {
    static let tvPrimaryRed = Color.red
}
