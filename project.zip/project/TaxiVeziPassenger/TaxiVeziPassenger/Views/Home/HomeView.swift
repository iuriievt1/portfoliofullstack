//
//  HomeView.swift
//  TaxiVeziPassenger
//
//  Created by Iurii Evteev on 12/15/25.
//

import SwiftUI
import MapKit

struct HomeView: View {
    @StateObject private var locationManager = LocationManager()
    @EnvironmentObject var appSession: AppSession

    @State private var pickupText: String = "Moje poloha"
    @State private var destinationText: String = ""

    @State private var hasActiveOrder: Bool = false
    @State private var activeTariffName: String = ""
    @State private var activeNote: String = ""
    @State private var activeRideId: String?

    @State private var activeSheet: ActiveSheet?

    private let ridesAPI = RidesAPI()
    @State private var debugAlertText: String?
    @State private var showDebugAlert: Bool = false

    enum ActiveSheet: Identifiable {
        case tariff, address, orderStatus
        var id: Int { hashValue }
    }

    var body: some View {
        ZStack {
            Map(coordinateRegion: $locationManager.region, showsUserLocation: true)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                HStack {
                    Text("TAXI VEZI")
                        .font(.headline)
                        .fontWeight(.bold)
                        .padding(8)
                        .background(Color.white.opacity(0.9))
                        .cornerRadius(12)

                    Spacer()

                    Button("Logout") { appSession.logout() }
                        .font(.caption)
                        .padding(8)
                        .background(Color.white.opacity(0.9))
                        .cornerRadius(10)
                }
                .padding(.top, 16)
                .padding(.horizontal, 16)

                Spacer()

                if hasActiveOrder {
                    VStack(spacing: 12) {
                        Capsule()
                            .fill(Color.gray.opacity(0.3))
                            .frame(width: 40, height: 4)
                            .padding(.top, 6)

                        VStack(alignment: .leading, spacing: 4) {
                            Text("Řidič je na cestě")
                                .font(.subheadline)
                                .fontWeight(.semibold)

                            Text("\(pickupText) → \(destinationText)")
                                .font(.footnote)
                                .foregroundColor(.gray)
                                .lineLimit(1)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)

                        Button {
                            activeSheet = .orderStatus
                        } label: {
                            Text("Zobrazit stav jízdy")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.tvPrimaryRed)
                                .foregroundColor(.white)
                                .cornerRadius(16)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 24)
                    .background(
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .fill(.ultraThinMaterial)
                            .shadow(color: Color.black.opacity(0.2), radius: 18, x: 0, y: -4)
                    )
                    .padding(.horizontal, 16)
                    .padding(.bottom, 8)

                } else {
                    RideSearchPanel(
                        pickupText: $pickupText,
                        destinationText: $destinationText,
                        onSearchTap: {
                            let dest = destinationText.trimmingCharacters(in: .whitespaces)
                            guard !dest.isEmpty else { return }
                            activeSheet = .tariff
                        },
                        onDestinationTap: {
                            activeSheet = .address
                        }
                    )
                    .padding(.horizontal, 16)
                    .padding(.bottom, 24)
                }

                Button {
                    Task { await testBackendRide() }
                } label: {
                    Text("Test backend ride")
                        .font(.footnote)
                        .padding(8)
                        .frame(maxWidth: .infinity)
                        .background(Color.black.opacity(0.06))
                        .cornerRadius(10)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 8)
            }
        }
        .task { await syncActiveRideFromBackend() }
        .sheet(item: $activeSheet) { sheet in
            switch sheet {
            case .tariff:
                TariffSelectionView(
                    pickup: pickupText,
                    destination: destinationText,
                    onConfirm: { selectedTariff, note in
                        Task { await startRideWithBackend(tariffName: selectedTariff, note: note) }
                    }
                )
            case .address:
                AddressSearchView(searchText: $destinationText)
            case .orderStatus:
                OrderStatusView(
                    pickup: pickupText,
                    destination: destinationText,
                    tariffName: activeTariffName,
                    note: $activeNote,
                    isOrderActive: $hasActiveOrder,
                    rideId: $activeRideId
                )
                .environmentObject(appSession)
            }
        }
        .alert("Debug backend ride", isPresented: $showDebugAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(debugAlertText ?? "")
        }
    }

    private func syncActiveRideFromBackend() async {
        guard let token = appSession.authToken, !token.isEmpty else { return }

        do {
            if let ride = try await ridesAPI.getActiveRide(token: token),
               ride.status != .completed,
               ride.status != .canceled {

                await MainActor.run {
                    activeRideId = ride.id
                    pickupText = ride.pickupAddress
                    destinationText = ride.destinationAddress
                    activeTariffName = (ride.carType ?? "Economy").capitalized
                    hasActiveOrder = true
                }
            } else {
                await MainActor.run {
                    activeRideId = nil
                    hasActiveOrder = false
                }
            }
        } catch {
            await MainActor.run {
                debugAlertText = "Chyba při načítání aktivní jízdy: \(error.localizedDescription)"
                showDebugAlert = true
            }
        }
    }

    private func startRideWithBackend(tariffName: String, note: String) async {
        let dest = destinationText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !dest.isEmpty else { return }

        guard let token = appSession.authToken, !token.isEmpty else {
            await MainActor.run {
                debugAlertText = "Chybí token. Nejprve se přihlaste."
                showDebugAlert = true
            }
            return
        }

        let center = locationManager.region.center
        let pickupLat = center.latitude
        let pickupLng = center.longitude

        let destinationLat = pickupLat
        let destinationLng = pickupLng

        do {
            let ride = try await ridesAPI.requestRide(
                token: token,
                pickupAddress: pickupText,
                pickupLat: pickupLat,
                pickupLng: pickupLng,
                destinationAddress: dest,
                destinationLat: destinationLat,
                destinationLng: destinationLng,
                carType: tariffName.lowercased()
            )

            await MainActor.run {
                activeRideId = ride.id
                pickupText = ride.pickupAddress
                destinationText = ride.destinationAddress
                activeTariffName = tariffName
                activeNote = note
                hasActiveOrder = true
                activeSheet = .orderStatus
            }
        } catch {
            await MainActor.run {
                debugAlertText = "Chyba při vytvoření jízdy: \(error.localizedDescription)"
                showDebugAlert = true
            }
        }
    }

    private func testBackendRide() async {
        guard let token = appSession.authToken, !token.isEmpty else {
            await MainActor.run {
                debugAlertText = "Нет токена. Сначала пройди авторизацию."
                showDebugAlert = true
            }
            return
        }

        do {
            let ride = try await ridesAPI.requestRide(
                token: token,
                pickupAddress: "Václavské náměstí 1",
                pickupLat: 50.083,
                pickupLng: 14.425,
                destinationAddress: "Letiště Praha",
                destinationLat: 50.106,
                destinationLng: 14.269,
                carType: "economy"
            )

            await MainActor.run {
                debugAlertText = """
                Заказ создан:
                id: \(ride.id)
                status: \(ride.status.rawValue)
                z: \(ride.pickupAddress)
                do: \(ride.destinationAddress)
                """
                showDebugAlert = true
            }
        } catch {
            await MainActor.run {
                debugAlertText = "Ошибка: \(error.localizedDescription)"
                showDebugAlert = true
            }
        }
    }
}
