import { randomUUID } from "crypto";

export type RideStatus =
  | "searching_driver"
  | "driver_assigned"
  | "on_the_way"
  | "in_progress"
  | "completed"
  | "canceled";

export interface Ride {
  id: string;
  passengerId: string;
  driverId?: string | null;

  pickupAddress: string;
  pickupLat: number;
  pickupLng: number;

  destinationAddress: string;
  destinationLat: number;
  destinationLng: number;

  carType?: string;

  status: RideStatus;
  createdAt: string;
  updatedAt: string;
}

// In-memory
const rides: Ride[] = [];

// Статусы (общая цепочка)
const RIDE_STATUS_FLOW: RideStatus[] = [
  "searching_driver",
  "driver_assigned",
  "on_the_way",
  "in_progress",
  "completed",
];

export function getNextRideStatus(current: RideStatus): RideStatus | null {
  if (current === "completed" || current === "canceled") return null;
  const index = RIDE_STATUS_FLOW.indexOf(current);
  if (index === -1) return null;
  return RIDE_STATUS_FLOW[index + 1] ?? null;
}

// Создать поездку (пассажир)
export function createRide(params: {
  passengerId: string;
  pickupAddress: string;
  pickupLat: number;
  pickupLng: number;
  destinationAddress: string;
  destinationLat: number;
  destinationLng: number;
  carType?: string;
}): Ride {
  const now = new Date().toISOString();

  const ride: Ride = {
    id: randomUUID(),
    passengerId: params.passengerId,
    driverId: null,
    pickupAddress: params.pickupAddress,
    pickupLat: params.pickupLat,
    pickupLng: params.pickupLng,
    destinationAddress: params.destinationAddress,
    destinationLat: params.destinationLat,
    destinationLng: params.destinationLng,
    carType: params.carType,
    status: "searching_driver",
    createdAt: now,
    updatedAt: now,
  };

  rides.push(ride);
  return ride;
}

export function findRideById(id: string): Ride | undefined {
  return rides.find((r) => r.id === id);
}

// Пассажир: активная поездка
export function findActiveRideForPassenger(passengerId: string): Ride | undefined {
  return rides.find(
    (r) =>
      r.passengerId === passengerId &&
      r.status !== "completed" &&
      r.status !== "canceled"
  );
}

// Пассажир: история
export function findRidesForPassenger(passengerId: string): Ride[] {
  return rides
    .filter((r) => r.passengerId === passengerId)
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

// Пассажир: отмена
export function cancelRideById(id: string, passengerId: string): Ride | undefined {
  const ride = rides.find((r) => r.id === id && r.passengerId === passengerId);
  if (!ride) return undefined;

  ride.status = "canceled";
  ride.updatedAt = new Date().toISOString();
  return ride;
}

// Пассажир: тестовый next-status (только для твоих тестов)
export function moveRideToNextStatus(rideId: string): Ride | null {
  const ride = findRideById(rideId);
  if (!ride) return null;

  const nextStatus = getNextRideStatus(ride.status);
  if (!nextStatus) return null;

  if (nextStatus === "driver_assigned" && !ride.driverId) {
    ride.driverId = "mock-driver-1";
  }

  ride.status = nextStatus;
  ride.updatedAt = new Date().toISOString();
  return ride;
}

/* =========================
   DRIVER SIDE
========================= */

// Водитель: доступные (ищем водителя)
export function findAvailableRidesForDriver(): Ride[] {
  return rides
    .filter((r) => r.status === "searching_driver")
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

// Водитель: активная (назначена этому водителю и не завершена)
export function findActiveRideForDriver(driverId: string): Ride | undefined {
  return rides.find(
    (r) =>
      r.driverId === driverId &&
      r.status !== "completed" &&
      r.status !== "canceled" &&
      r.status !== "searching_driver"
  );
}

// Водитель: принять поездку
export function acceptRideByDriver(rideId: string, driverId: string): Ride | null {
  const ride = findRideById(rideId);
  if (!ride) return null;

  if (ride.status !== "searching_driver") return null;
  if (ride.driverId) return null;

  ride.driverId = driverId;
  ride.status = "driver_assigned";
  ride.updatedAt = new Date().toISOString();
  return ride;
}

// Водитель: двигать статус дальше
export function moveRideToNextStatusByDriver(rideId: string, driverId: string): Ride | null {
  const ride = findRideById(rideId);
  if (!ride) return null;
  if (ride.driverId !== driverId) return null;

  const next = getNextRideStatus(ride.status);
  if (!next) return null;

  ride.status = next;
  ride.updatedAt = new Date().toISOString();
  return ride;
}
