//
//  DriverAppSession.swift
//  TaxiVeziDriver
//
//  Created by Iurii Evteev on 12/15/25.
//

import Foundation
import Combine

final class DriverAppSession: ObservableObject {
    @Published var isLoggedIn: Bool = false
    @Published var driverApproved: Bool = false

    @Published var driverPhone: String = ""
    @Published var driverName: String = ""

    // JWT драйвера
    @Published var authToken: String? = nil

    func logout() {
        isLoggedIn = false
        driverApproved = false
        driverPhone = ""
        driverName = ""
        authToken = nil
    }
}
