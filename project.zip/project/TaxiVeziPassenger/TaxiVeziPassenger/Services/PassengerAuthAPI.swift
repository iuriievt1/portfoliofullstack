//
//  PassengerAuthAPI.swift
//  TaxiVeziPassenger
//
//  Created by Iurii Evteev on 12/15/25.
//

import Foundation

private struct PassengerStartLoginResponse: Codable {
    let success: Bool
    let message: String?
}

private struct PassengerVerifyResponse: Codable {
    let success: Bool
    let message: String?
    let token: String?
}

enum PassengerAuthAPIError: Error, LocalizedError {
    case invalidURL
    case badResponse
    case server(String)
    case noToken

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid URL"
        case .badResponse: return "Bad response from server"
        case .server(let msg): return msg
        case .noToken: return "Missing token in response"
        }
    }
}

struct PassengerAuthAPI {
    private let baseURL = URL(string: "http://localhost:4000")!

    private func makeRequest(path: String, method: String = "POST", body: Data? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: baseURL) else {
            throw PassengerAuthAPIError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            throw PassengerAuthAPIError.badResponse
        }

        return data
    }

    // POST /auth/passenger/request-code
    func startLogin(phone: String) async throws {
        let payload: [String: Any] = ["phone": phone]
        let body = try JSONSerialization.data(withJSONObject: payload, options: [])

        let data = try await makeRequest(path: "/auth/passenger/request-code", method: "POST", body: body)
        let decoded = try JSONDecoder().decode(PassengerStartLoginResponse.self, from: data)

        if let message = decoded.message, decoded.success == false {
            throw PassengerAuthAPIError.server(message)
        }
    }

    // POST /auth/passenger/verify
    func verifyCode(phone: String, code: String) async throws -> String {
        let payload: [String: Any] = ["phone": phone, "code": code]
        let body = try JSONSerialization.data(withJSONObject: payload, options: [])

        let data = try await makeRequest(path: "/auth/passenger/verify", method: "POST", body: body)
        let decoded = try JSONDecoder().decode(PassengerVerifyResponse.self, from: data)

        if let message = decoded.message, decoded.success == false {
            throw PassengerAuthAPIError.server(message)
        }
        guard let token = decoded.token else { throw PassengerAuthAPIError.noToken }
        return token
    }
}
